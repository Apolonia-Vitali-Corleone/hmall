create
    definer = root@`%` procedure generate_titles()
BEGIN
    DECLARE i INT DEFAULT 0;
    WHILE i < 100000 DO
            INSERT INTO article_titles (title)
            VALUES (CONCAT('Title ', FLOOR(RAND() * 1000000))); -- 生成随机标题
            SET i = i + 1;
        END WHILE;
END;

